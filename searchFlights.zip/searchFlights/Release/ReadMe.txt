========================================================================
    CONSOLE APPLICATION : searchFlights Project Overview
========================================================================

AppWizard has created this searchFlights application for you.

This file contains a summary of what you will find in each of the files that
make up your searchFlights application.


searchFlights.vcproj
    This is the main project file for VC++ projects generated using an Application Wizard.
    It contains information about the version of Visual C++ that generated the file, and
    information about the platforms, configurations, and project features selected with the
    Application Wizard.

searchFlights.cpp
    This is the main application source file.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named searchFlights.pch and a precompiled types file named StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Other notes:
	to run the application, just entering the SearchFlight/Release folder,
	then double click on searchFlights.exe. A terminal window will appear.
	Then entering the input as : -o YYC -d YYZ and press ENTER. The output
	is generated in flightSearchOutput.txt
	
AppWizard uses "TODO:" comments to indicate parts of the source code you
should add to or customize.

/////////////////////////////////////////////////////////////////////////////
