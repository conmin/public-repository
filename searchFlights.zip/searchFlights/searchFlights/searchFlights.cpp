// searchFlights.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <locale>
#include <time.h>
#include <iomanip>
#include <process.h>
#include <conio.h>

typedef struct flightInfo
{
    std::string Origin;
    std::string DepartureTime;
    std::string Destination;
    std::string DestinationTime;
    float Price; 
    flightInfo *next;
} *fInfoPointer;

std::string inputOrigin; 
std::string inputDestination;


time_t StrToTime(std::string &inputStr);
void flightSearch(std::ifstream &file, std::string &delimiter);
void flightSearch1(void *p);
void flightSearch2(void *p);
void flightSearch3(void *p);
void searchOutput();
fInfoPointer fInfoFirst=NULL;
HANDLE pMutex;

int _tmain(int argc, _TCHAR* argv[])
{
	// insert code here...
	char inC[3];
    std::cin >> inC;
	std::cin >> inputOrigin;
	std::cin >> inC;
    std::cin >> inputDestination;

	// Handling reading 3 data files simultaneously in different threads
	pMutex = CreateMutex(NULL, false, NULL);
    HANDLE pth1 = (HANDLE)_beginthread(flightSearch1,0,0);
    HANDLE pth2 = (HANDLE)_beginthread(flightSearch2,0,0);
	HANDLE pth3 = (HANDLE)_beginthread(flightSearch3,0,0);

	// Waiting for these threads finished before print the output into output file
    WaitForSingleObject(pth1, INFINITE);
	WaitForSingleObject(pth2, INFINITE);
	WaitForSingleObject(pth3, INFINITE);
	searchOutput();

	return 0;
}

time_t StrToTime( std::string &inputStr)
{
	struct tm tm2;
	std::string timeStr = inputStr;
	std::string deler = "/";
	size_t pos = timeStr.find(deler);
	tm2.tm_mon = atoi(timeStr.substr(0, pos).c_str());
	timeStr.erase(0, pos+deler.length());
	pos = timeStr.find(deler);
	tm2.tm_mday = atoi(timeStr.substr(0, pos).c_str());
	timeStr.erase(0, pos+deler.length());
	pos = timeStr.find(deler);
	tm2.tm_year = atoi(timeStr.substr(0, pos).c_str());
	timeStr.erase(0, pos+deler.length()+1);
	deler = ":";
	pos = timeStr.find(deler);
	tm2.tm_hour = atoi(timeStr.substr(0, pos).c_str());
	timeStr.erase(0, pos+deler.length());
	pos = timeStr.find(deler);
	tm2.tm_min = atoi(timeStr.substr(0, pos).c_str());
	timeStr.erase(0, pos+deler.length());
	pos = timeStr.find(deler);
	tm2.tm_sec = atoi(timeStr.substr(0, pos).c_str());
	time_t t = mktime(&tm2);

	return t;
}

void flightSearch1(void *p)
{
	std::string delimiter=",";
	std::ifstream file("Provider1.txt");
	flightSearch(file, delimiter);
}

void flightSearch2(void *p)
{
	std::string delimiter=",";
	std::ifstream file("Provider2.txt");
	flightSearch(file, delimiter);
}

void flightSearch3(void *p)
{
	std::string delimiter="|";
	std::ifstream file("Provider3.txt");
	flightSearch(file, delimiter);
}

void flightSearch(std::ifstream &file, std::string &delimiter)
{
	std::string str;
    fInfoPointer fInfo=NULL;
    int j=0,i=0;
    j = 0;
    while (std::getline(file, str))
    {
       // skip the header line
         if (j == 0)
         {
             j = 1;
             continue;
         }
         fInfo = new struct flightInfo;
         size_t pos = 0;
         std::string token;
         i=0;
         while ((pos = str.find(delimiter)) != std::string::npos) {
             if (i == 0)
                 fInfo->Origin = str.substr(0, pos);
             else if (i == 1)
                 fInfo->DepartureTime = str.substr(0, pos);
             else if (i == 2)
                 fInfo->Destination = str.substr(0, pos);
             else if (i == 3)
                 fInfo->DestinationTime = str.substr(0, pos);
             str.erase(0, pos + delimiter.length());
             i++;
          }
          if (fInfo->Origin.compare(inputOrigin) != 0 || fInfo->Destination.compare(inputDestination) != 0)
          {
              continue;
          }
          str.erase(0,1);
          fInfo->Price = (float)atof(str.c_str());
		  // Locking until this thread finishing the data insertion
		  WaitForSingleObject(pMutex, INFINITE);
          if (fInfoFirst == NULL)
          {
              fInfoFirst = fInfo;
              fInfoFirst->next = NULL;
          }
          else
          {
              fInfoPointer fItem = fInfoFirst;
              time_t t2 = StrToTime(fInfo->DepartureTime);
              if (fItem->Origin.compare(fInfo->Origin) == 0 &&
                    fItem->DepartureTime.compare(fInfo->DepartureTime) == 0 &&
                    fItem->Destination.compare(fInfo->Destination) == 0 &&
                    fItem->DestinationTime.compare(fInfo->DestinationTime) == 0 &&
                    fItem->Price == fInfo->Price)
              {
                    delete fInfo;
					ReleaseMutex(pMutex);
                    continue;
              }
              else // Sorting by Price first then by Departure Time 
              {
                    if (fItem->Price == fInfo->Price)
                    {
                        time_t t1 = StrToTime(fItem->DepartureTime);
                    
                        if (t1 == t2 || t1 > t2)
                        {
                            fInfoFirst = fInfo;
                            fInfo->next = fItem;
                            fItem->next= NULL;
                        }
                        else
                        {
                            if (fItem->next == NULL)
                            {
                                fItem->next= fInfo;
                                fInfo->next = NULL;
                            }
                            else
                            {
                                fInfoPointer prevInfo = fItem;
                                fItem = fItem->next;
                                bool found = false;
                                while (fItem && fItem->Price == fInfo->Price)
                                {
                                    time_t t3 = StrToTime(fItem->DepartureTime);
                                    if (t3 < t2 || t3 == t2)
                                    {
                                        prevInfo->next = fInfo;
                                        fInfo->next = fItem;
                                        found = true;
                                        break;
                                    }
                                }
                                if (!found)
                                {
                                    prevInfo = fInfo;
                                    fInfo->next = fItem;
                                }
                            }
                        }
                    }
                    else if (fItem->Price > fInfo->Price)
                    {
                        fInfoFirst = fInfo;
                        fInfo->next = fItem;
                    }
                    else
                    {
                        if (fItem->next == NULL)
                        {
                            fItem->next= fInfo;
                            fInfo->next = NULL;
                        }
                        else
                        {
                            fInfoPointer prevInfo = fItem;
                            fItem = fItem->next;
                            bool found = false;
                            while (fItem && fItem->Price > fInfo->Price)
                            {
                                prevInfo = fInfo;
                                fInfo->next = fItem;
                                found = true;
                                break;
                            }
                            if (found)
                            {
                                prevInfo = fInfo;
                                fInfo->next = fItem;
                            }
                            else
                            {
                                if (fItem->Price == fInfo->Price)
                                {
                                    found = false;
                                    while (fItem && fItem->Price == fInfo->Price)
                                    {
                                        prevInfo = fInfo;
                                        fInfo->next = fItem;
                                        time_t t3 = StrToTime(fItem->DepartureTime);
                                        if (t3 < t2 || t3 == t2)
                                        {
                                            prevInfo->next = fInfo;
                                            fInfo->next = fItem;
                                            found = true;
                                            break;
                                        }
                                        else
                                            fItem = fItem->next;
                                    }
                                    if (!found)
                                    {
                                        prevInfo = fInfo;
                                        fInfo->next = fItem;
                                    }
                                }
                                else
                                {
                                    prevInfo = fInfo;
                                    fInfo->next = fItem;
                                }
                            }
                        }
                    }
              }
          }
		  ReleaseMutex(pMutex);
        }
}

void searchOutput()
{
    fInfoPointer fItem = fInfoFirst;
    fInfoPointer fPrevInfo=NULL, fBeforePrev=NULL;
	std::ofstream file("flightSearchOutput.txt");
    while (fItem)
    {
        file << fItem->Origin << " --> " << fItem->Destination << " (";
		char depTime[20];
		strcpy_s(depTime, fItem->DepartureTime.c_str());
		for (int i=0;i<7;i++)
		{
			if (depTime[i] == '-')
				depTime[i] = '/';
		}
        file << depTime << " --> ";
		strcpy_s(depTime, fItem->DestinationTime.c_str());
		for (int i=0;i<7;i++)
		{
			if (depTime[i] == '-')
				depTime[i] = '/';
		}
		file << depTime << ") - $";
        file << std::fixed;
        file << std::setprecision(2);
        file << fItem->Price << std::endl;
        fBeforePrev = fPrevInfo;
        fPrevInfo = fItem;
        fItem = fItem->next;
        delete fBeforePrev;
    }
    if (fPrevInfo)
        delete fPrevInfo;
}