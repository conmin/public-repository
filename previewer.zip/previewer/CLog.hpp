/**
 * @file CLog.hpp
 * @brief Header of CLog
 * @author Joe
 * @author Nikki Tan
 * @author Titan Lien
 * @version 0.4
 * @todo 1. Fixed the blocking of syslog().....\n
 *       2. if CLog needs to worry about system signals like SIGSEGV!
 */

#ifndef _CLOG_HPP_
#define _CLOG_HPP_

#include <iostream>
#include <string>

#include <boost/log/attributes/current_process_id.hpp>
#include <boost/log/attributes/current_thread_id.hpp>
#include <boost/log/attributes/value_extraction.hpp>
#include <boost/log/attributes.hpp>
#include <boost/log/common.hpp>
#include <boost/log/core.hpp>
#include <boost/log/detail/locking_ptr.hpp>
#include <boost/log/expressions/attr.hpp>
#include <boost/log/expressions/formatters/xml_decorator.hpp>
#include <boost/log/expressions/formatters.hpp>
#include <boost/log/expressions/message.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/sinks.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/utility/formatting_ostream.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/utility/setup/console.hpp>
#include <boost/log/utility/setup/file.hpp>
#include <boost/log/utility/setup/filter_parser.hpp>
#include <boost/log/utility/setup/formatter_parser.hpp>
#include <boost/log/utility/string_literal.hpp>
#include <boost/log/utility/type_info_wrapper.hpp>
#include <boost/noncopyable.hpp>

namespace logging = boost::log;
namespace sinks = boost::log::sinks;
namespace src = boost::log::sources;
namespace flt = boost::log;
namespace attrs = boost::log::attributes;
namespace keywords = boost::log::keywords;
namespace triv = boost::log::trivial;
namespace expr = boost::log::expressions;

/**
 * @class CLog
 * @brief In charge of run-time logging.
 * @note CLog logs to system logs.
 * 		 It uses the technology of boost.log http://http://boost-log.sourceforge.net/
 */
class CLog : private boost::noncopyable
{
public:
	///Frequently used logging phrase.
	static const char* const sJustSteppedIn;
	///Frequently used logging phrase.
	static const char* const sSuccess;
	///Frequently used logging phrase.
	static const char* const sReturnTrue;
	///Frequently used logging phrase.
	static const char* const sReturnFalse;
	///Frequently used logging phrase.
	static const char* const sFailed;
	///Frequently used logging phrase.
	static const char* const sExit;
	/**
	 * @enum LEVEL
	 * @brief Enum for different levels of logging.\n
	 */
	enum LEVEL
	{	TRACE = 0,
		DEBUG = 1,
		INFO = 2,
		WARNING = 3,
		ERROR = 4,
		FATAL = 5,
		INIT
	};

    /**
     * Ctor.
     */
    CLog(CLog::LEVEL level);

	/**
	 * Dtor.
	 */
	~CLog();

    /**
     * Logs debugging messages of trace level.
     * @param strFunc [in] From which function are you logging?
     * @param strMsg [in] The actual message.
     * @param strClass [in] Which class that you are logging from?
     */
    void Trace(const std::string& strFunc,
               const std::string& strMsg,
               const std::string& strClass);

    /**
     * Logs debugging messages of LOG_DEBUG level.
     * @param strFunc [in] From which function are you logging?
     * @param strMsg [in] The actual message.
     * @param strClass [in] Which class that you are logging from?
     */
    void Debug(const std::string& strFunc,
               const std::string& strMsg,
               const std::string& strClass);
	/**
	 * Add log msg
	 * @param strFunc [in] From which function are you logging?
	 * @param strMsg [in] The actual message.
	 * @param strClass [in] Which class that you are logging from?
	 */
	void Info(const std::string& strFunc,
	          const std::string& strMsg,
			  const std::string& strClass);
    /**
     * Logs messages of LOG_WARN level.
     * @param strFunc [in] From which function are you logging?
     * @param strMsg [in] The actual message.
     * @param strClass [in] Which class that you are logging from?
     */
    void Warn(const std::string& strFunc,
              const std::string& strMsg,
              const std::string& strClass);
	/**
	 * @brief Logs error message.
	 * @param strFunc [in] From which function are you logging?
	 * @param strMsg [in] The actual message.
	 * @param nLine [in] Which line in the code that you are logging from?
	 * @param chFile [in] Which file that you are logging from?
	 * @param strClass [in] Which class that you are logging from?
	 */
	void Error(const std::string& strFunc,
			const std::string& strMsg,
			int nLine,
			const char* chFile,
			const std::string& strClass);

	/**
     * @brief Logs fatal message.
     * @param strFunc [in] From which function are you logging?
     * @param strMsg [in] The actual message.
     * @param nLine [in] Which line in the code that you are logging from?
     * @param chFile [in] Which file that you are logging from?
     * @param strClass [in] Which class that you are logging from?
     */
    void Fatal(const std::string& strFunc,
            const std::string& strMsg,
            int nLine,
            const char* chFile,
            const std::string& strClass);

	/**
	 * Sets log level.\n
	 * @param l The new level to be set.
	 * @return The old level.
	 */
	LEVEL SetLogLevel(LEVEL l);

	/**
	 * Sets log level to @a l and up.
	 * @param l The level you'd like to set.
	 * @return The previous level.
	 */
	LEVEL SetLogLevelAndUp(LEVEL l);

	/**
	 * Get current log level.\n
	 * @return Current log level.
	 */
	CLog::LEVEL GetLogLevel();

	/**
	 * redirect cout to some log level
	 * @param desired log level
	 */
	void SetCout2LogLevel(LEVEL l);

	/// restore cout to normal
	void RestoreCout();

private:
	///TODO:
	std::string LogLevel2String(CLog::LEVEL l);

	///To keeps track of current log level.
	LEVEL mLogLevel;
	///To keeps track of previous log level.
	LEVEL mPrevLogLevel;
    /// backup cout streaming
    std::streambuf* mBackupCoutBuf;

	static const std::string sClsName;
};


#endif

