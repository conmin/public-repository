/****************************************************************************
**
** Copyright (C) 2013 Digia Plc and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/legal
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Digia Plc and its Subsidiary(-ies) nor the names
**     of its contributors may be used to endorse or promote products derived
**     from this software without specific prior written permission.
**
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtWidgets>
#include <QTime>
#include <QDir>
#include "mainwindow.h"


#define LOAD_INTERVAL 10000


MainWindow::MainWindow():
logObj(CLog::INIT)
{
    centralWidget = new Previewer(this);
    setCentralWidget(centralWidget);
    setWindowState((windowState() &
                    ~(Qt::WindowMinimized |
                      Qt::WindowMaximized |
                      Qt::WindowFullScreen)));
    selNum = 0;
    open();

    connect(centralWidget->webView, SIGNAL(loadFinished(bool)),
        this, SLOT(viewLoadFinished()));
    connect(centralWidget->webView_2, SIGNAL(loadFinished(bool)),
        this, SLOT(view2LoadFinished()));

    updateWebView();

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateWebView()));
    timer->start(LOAD_INTERVAL);
    showFullScreen();

}


void MainWindow::open()
{
    QString fileName = QDir::currentPath();
    fileName.remove("previewer.app/Contents/MacOS");
    fileName.append("url.list");
    if (!fileName.isEmpty()) {
        // read from file
        QFile file(fileName);

        if (!file.open(QIODevice::ReadOnly)) {
            fileName = QFileDialog::getOpenFileName(this);
            if (!fileName.isEmpty()) {
                QFile file1(fileName);
                if (!file1.open(QIODevice::ReadOnly)) {
                    QMessageBox::information(this, tr("Unable to open file"),
                        file1.errorString());
                    exit(1);
                }
                QString str;
                while (!file1.atEnd())
                {
                    str = file1.readLine();
                    str.remove("\n");
                    urlList.append(str);
                    selNum++;
                }
                return;
            }
            QMessageBox::information(this, tr("Unable to open file"),
                file.errorString());
            exit(1);
        }
        QString str;
        while (!file.atEnd())
        {
            str = file.readLine();
            str.remove("\n");
            urlList.append(str);
            selNum++;
        }
    }
}

void MainWindow::openViewUrl()
{
    int i=0;
    QTime time = QTime::currentTime();
    qsrand((uint)time.msec());
    i = rand()%selNum;
    if (!urlList.at(i).isEmpty()) {
        QString url = "http://"+urlList.at(i);
        centralWidget->webView->setUrl(url);
    }
    syslog(i);
}

void MainWindow::openView2Url()
{
    int i=0;
    QTime time = QTime::currentTime();
    qsrand((uint)time.msec());
    i = rand()%selNum;
    if (!urlList.at(i).isEmpty()) {
        QString url = "http://"+urlList.at(i);
        centralWidget->webView_2->setUrl(url);
    }
    syslog(i);
}

void MainWindow::updateWebView()
{
    openViewUrl();
    openView2Url();
}


int MainWindow::syslog(int& i)
{
    if (i == 0)
    {
        logObj.SetLogLevel(CLog::INFO);
        logObj.Info("syslog",(char *)urlList.at(i).data(), "MainWindow");
    }
    else if (i == 1)
    {
        logObj.SetLogLevel(CLog::DEBUG);
        logObj.Debug("syslog",(char *)urlList.at(i).data(), "MainWindow");
    }
    else if (i == 2)
    {
        logObj.SetLogLevel(CLog::ERROR);
        logObj.Error("syslog",(char *)urlList.at(i).data(), 169, "mainwindow.cpp", "MainWindow");
    }
    else if (i == 3)
    {
        logObj.SetLogLevel(CLog::INIT);
        logObj.Info("syslog",(char *)urlList.at(i).data(), "MainWindow");
    }
    else if (i == 4)
    {
        logObj.SetLogLevel(CLog::TRACE);
        logObj.Trace("syslog",(char *)urlList.at(i).data(), "MainWindow");
    }
    else if (i == 5)
    {
        logObj.SetLogLevel(CLog::FATAL);
        logObj.Fatal("syslog",(char *)urlList.at(i).data(), 184, "mainwindow.cpp", "MainWindow");
    }
    else
    {
        logObj.SetLogLevel(CLog::WARNING);
        logObj.Warn("syslog",(char *)urlList.at(i).data(), "MainWindow");
    }
    return 0;
}

