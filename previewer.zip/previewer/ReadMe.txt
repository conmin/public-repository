This project is to display two webviews with url got randomly from url.list.
These urls are changed by 10 sec interval.
The url.list is included here but you can delete it and replace with your own file.
If no url.list in the project folder, it will open a file dialog to allow you to select that file.
To use CMake build the project.You need to set QT_LIB_DIR and BOOST_ROOT variables.
To compile this project you need a qt5.2.1 and boost_1_54_0 package.
The boost_1_54_0 lib folder and source folder should be in the LD_LIBRARY_PATH to run with dynamic boost libs as well as libdigbil.so
